---
layout: default
title: Another page
description: This is just another page
---

## Welcome to another page

_yay_

[back](./)
